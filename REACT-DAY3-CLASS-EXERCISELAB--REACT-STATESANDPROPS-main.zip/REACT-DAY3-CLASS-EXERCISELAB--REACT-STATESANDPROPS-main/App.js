
import './App.css';
import MenuItem from './MenuItem';



function App() {
  return (
    <div className="App">
      
 <MenuItem/>
    </div>
  );
}

export default App;
